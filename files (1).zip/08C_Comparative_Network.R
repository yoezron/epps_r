# ============================================================================
# SCRIPT 08C: COMPARATIVE NETWORK ANALYSIS & PREDICTABILITY
# Network analysis across groups dan predictability analysis
# ============================================================================

load("output/data_processed.RData")

cat("\n=== COMPARATIVE NETWORK ANALYSIS & PREDICTABILITY ===\n\n")

# Rename untuk visualisasi
skor_aspek_label <- skor_aspek
names(skor_aspek_label) <- aspek_labels[aspek_epps]

# ===== 1. NETWORK COMPARISON BY GENDER =====
cat("--- Network Comparison by Gender ---\n")

# Detect gender column
gender_col <- names(data_raw)[grepl("Jenis.*Kelamin|Gender|gender", 
                                    names(data_raw), ignore.case = TRUE)]

if(length(gender_col) > 0 && !is.null(data_raw[[gender_col[1]]])) {
  gender_data <- data_raw[[gender_col[1]]]
  
  # Get unique groups (filter out NA and ensure minimum sample size)
  gender_groups <- table(gender_data)
  valid_groups <- names(gender_groups[gender_groups >= 100])
  
  if(length(valid_groups) >= 2) {
    cat("Comparing networks for groups:", paste(valid_groups, collapse = ", "), "\n")
    
    # Network per group
    network_by_gender <- list()
    
    for(group in valid_groups[1:min(2, length(valid_groups))]) {
      idx <- which(gender_data == group)
      data_group <- skor_aspek_label[idx, ]
      
      # Regularize if needed
      cor_group <- cor(data_group, use = "pairwise.complete.obs")
      eigenvalues <- eigen(cor_group)$values
      if(min(eigenvalues) < 0) {
        regularization <- abs(min(eigenvalues)) + 0.01
        diag(cor_group) <- diag(cor_group) + regularization
      }
      
      network_by_gender[[group]] <- tryCatch({
        estimateNetwork(data_group, 
                       default = "cor",
                       corMethod = "cor")
      }, error = function(e) {
        list(graph = cor_group)
      })
      
      # Plot network per group
      png(paste0("output/plots/Network_", gsub(" ", "_", group), ".png"),
          width = 2800, height = 2800, res = 300)
      qgraph(cor_group,
             layout = "spring",
             graph = "cor",
             threshold = 0.15,
             title = paste("Network Aspek EPPS -", group),
             labels = names(skor_aspek_label),
             label.cex = 1.0,
             vsize = 7,
             posCol = "#1A9850",
             negCol = "#D73027",
             theme = "colorblind")
      dev.off()
    }
    
    # Network Comparison Test (NCT)
    if(length(network_by_gender) == 2) {
      cat("Running Network Comparison Test (NCT)...\n")
      cat("Note: This may take several minutes\n")
      
      group_names <- names(network_by_gender)
      data_g1 <- skor_aspek_label[gender_data == group_names[1], ]
      data_g2 <- skor_aspek_label[gender_data == group_names[2], ]
      
      nct_result <- tryCatch({
        NCT(data_g1, data_g2,
            it = 100,  # Reduced iterations for speed
            test.edges = TRUE,
            test.centrality = TRUE,
            progressbar = FALSE)
      }, error = function(e) {
        cat("NCT failed:", e$message, "\n")
        NULL
      })
      
      if(!is.null(nct_result)) {
        # Save NCT results
        nct_summary <- data.frame(
          Test = c("Global Strength", "Network Structure", "Edge Invariance"),
          p_value = c(nct_result$glstrinv.pval, 
                     nct_result$nwinv.pval,
                     ifelse(is.null(nct_result$einv.pval), NA, nct_result$einv.pval))
        )
        
        write.csv(nct_summary, "output/tables/39_NCT_Gender_Comparison.csv", 
                 row.names = FALSE)
        
        # Plot NCT results
        if(!is.null(nct_result$einv.pvals)) {
          png("output/plots/Network_Gender_Comparison.png", 
              width = 3000, height = 2400, res = 300)
          plot(nct_result, what = "edge")
          dev.off()
        }
        
        cat("✓ NCT completed\n")
      }
    }
  }
} else {
  cat("Gender variable not found or insufficient data\n")
}

cat("\n")

# ===== 2. NETWORK COMPARISON BY EDUCATION =====
cat("--- Network Comparison by Education ---\n")

edu_col <- names(data_raw)[grepl("Pendidikan|Education|education", 
                                 names(data_raw), ignore.case = TRUE)]

if(length(edu_col) > 0 && !is.null(data_raw[[edu_col[1]]])) {
  edu_data <- data_raw[[edu_col[1]]]
  edu_groups <- table(edu_data)
  valid_edu <- names(edu_groups[edu_groups >= 100])
  
  if(length(valid_edu) >= 2) {
    cat("Comparing networks for education levels:", 
        paste(head(valid_edu, 2), collapse = " vs "), "\n")
    
    # Compare top 2 education levels
    for(group in head(valid_edu, 2)) {
      idx <- which(edu_data == group)
      data_edu <- skor_aspek_label[idx, ]
      
      cor_edu <- cor(data_edu, use = "pairwise.complete.obs")
      eigenvalues <- eigen(cor_edu)$values
      if(min(eigenvalues) < 0) {
        regularization <- abs(min(eigenvalues)) + 0.01
        diag(cor_edu) <- diag(cor_edu) + regularization
      }
      
      png(paste0("output/plots/Network_Edu_", gsub(" ", "_", group), ".png"),
          width = 2800, height = 2800, res = 300)
      qgraph(cor_edu,
             layout = "spring",
             graph = "cor",
             threshold = 0.15,
             title = paste("Network -", group),
             labels = names(skor_aspek_label),
             label.cex = 1.0,
             vsize = 7,
             posCol = "#1A9850",
             negCol = "#D73027",
             theme = "colorblind")
      dev.off()
    }
    
    cat("✓ Education networks created\n")
  }
} else {
  cat("Education variable not found or insufficient data\n")
}

cat("\n")

# ===== 3. NODE PREDICTABILITY =====
cat("--- Node Predictability Analysis ---\n")

# Compute predictability (R-squared for each node)
predictability <- numeric(ncol(skor_aspek_label))
names(predictability) <- names(skor_aspek_label)

for(i in 1:ncol(skor_aspek_label)) {
  # Predict node i from all other nodes
  target <- skor_aspek_label[, i]
  predictors <- skor_aspek_label[, -i]
  
  # Remove rows with NA
  complete_idx <- complete.cases(cbind(target, predictors))
  target_clean <- target[complete_idx]
  predictors_clean <- predictors[complete_idx, ]
  
  if(sum(complete_idx) > 20) {
    # Fit linear model
    model <- tryCatch({
      lm(target_clean ~ ., data = as.data.frame(predictors_clean))
    }, error = function(e) NULL)
    
    if(!is.null(model)) {
      predictability[i] <- summary(model)$r.squared
    }
  }
}

predictability_df <- data.frame(
  Aspek = names(skor_aspek_label),
  Predictability = round(predictability, 3),
  Variance_Explained = paste0(round(predictability * 100, 1), "%")
)

predictability_df <- predictability_df[order(predictability_df$Predictability, 
                                             decreasing = TRUE), ]

write.csv(predictability_df, "output/tables/40_Node_Predictability.csv", 
         row.names = FALSE)

# Plot predictability
library(ggplot2)

p_pred <- ggplot(predictability_df, 
                 aes(x = reorder(Aspek, Predictability), y = Predictability)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  geom_text(aes(label = Variance_Explained), hjust = -0.1, size = 3) +
  coord_flip() +
  ylim(0, 1) +
  theme_minimal(base_size = 11) +
  labs(title = "Node Predictability - Seberapa Predictable Tiap Aspek",
       subtitle = "R² dari regresi: prediksi aspek dari aspek lainnya",
       x = "Aspek", y = "Predictability (R²)")

ggsave("output/plots/Network_Predictability.png", p_pred, 
       width = 10, height = 8, dpi = 300)

cat("✓ Predictability computed\n")
cat("Mean predictability:", round(mean(predictability, na.rm = TRUE), 3), "\n\n")

# ===== 4. NETWORK WITH PREDICTABILITY VISUALIZATION =====
cat("--- Network with Predictability Pie Charts ---\n")

# Get correlation matrix
cor_matrix <- cor(skor_aspek_label, use = "pairwise.complete.obs")
eigenvalues <- eigen(cor_matrix)$values
if(min(eigenvalues) < 0) {
  regularization <- abs(min(eigenvalues)) + 0.01
  diag(cor_matrix) <- diag(cor_matrix) + regularization
}

png("output/plots/Network_With_Predictability.png", 
    width = 3200, height = 3200, res = 300)
qgraph(cor_matrix,
       layout = "spring",
       graph = "cor",
       threshold = 0.15,
       pie = predictability,
       pieBorder = 0.3,
       title = "Network dengan Predictability (Pie Charts)",
       labels = names(skor_aspek_label),
       label.cex = 0.9,
       vsize = 10,
       posCol = "#1A9850",
       negCol = "#D73027",
       theme = "colorblind",
       legend = TRUE)
dev.off()

cat("✓ Network with predictability created\n\n")

# ===== 5. STABILITY OF INDIVIDUAL EDGES =====
cat("--- Individual Edge Stability ---\n")

# Bootstrap edge weights
set.seed(2025)
n_boot <- 100
edge_boots <- array(NA, dim = c(ncol(skor_aspek_label), 
                                ncol(skor_aspek_label), 
                                n_boot))

sample_size <- min(1000, nrow(skor_aspek_label))

for(b in 1:n_boot) {
  boot_idx <- sample(1:nrow(skor_aspek_label), sample_size, replace = TRUE)
  boot_data <- skor_aspek_label[boot_idx, ]
  
  boot_cor <- cor(boot_data, use = "pairwise.complete.obs")
  edge_boots[, , b] <- boot_cor
}

# Compute edge stability (SD across bootstraps)
edge_stability <- apply(edge_boots, c(1, 2), sd, na.rm = TRUE)
rownames(edge_stability) <- colnames(edge_stability) <- names(skor_aspek_label)

# Get most stable edges
stable_edges <- data.frame(
  From = character(),
  To = character(),
  Mean_Weight = numeric(),
  SD = numeric(),
  CV = numeric()
)

for(i in 1:(ncol(cor_matrix)-1)) {
  for(j in (i+1):ncol(cor_matrix)) {
    mean_weight <- mean(edge_boots[i, j, ], na.rm = TRUE)
    sd_weight <- edge_stability[i, j]
    
    stable_edges <- rbind(stable_edges, data.frame(
      From = names(skor_aspek_label)[i],
      To = names(skor_aspek_label)[j],
      Mean_Weight = round(mean_weight, 3),
      SD = round(sd_weight, 3),
      CV = round(sd_weight / abs(mean_weight), 3)
    ))
  }
}

# Sort by stability (lowest SD or CV)
stable_edges <- stable_edges[order(stable_edges$SD), ]

# Top 20 most stable edges
write.csv(head(stable_edges, 20), 
          "output/tables/41_Most_Stable_Edges.csv", 
          row.names = FALSE)

# Top 20 least stable edges
write.csv(tail(stable_edges, 20), 
          "output/tables/42_Least_Stable_Edges.csv", 
          row.names = FALSE)

cat("✓ Edge stability computed (", n_boot, "bootstraps)\n\n")

# ===== 6. EXPECTED INFLUENCE =====
cat("--- Expected Influence Analysis ---\n")

library(igraph)

# Create weighted graph
g <- graph_from_adjacency_matrix(cor_matrix, 
                                 mode = "undirected", 
                                 weighted = TRUE,
                                 diag = FALSE)

# Compute expected influence (sum of edge weights)
expected_influence <- numeric(ncol(cor_matrix))
for(i in 1:ncol(cor_matrix)) {
  # Get all edges connected to node i
  edges_connected <- E(g)[inc(i)]
  expected_influence[i] <- sum(abs(E(g)$weight[edges_connected]))
}

# One-step expected influence
expected_influence_1 <- colSums(abs(cor_matrix)) - diag(abs(cor_matrix))

# Two-step expected influence
cor_matrix_squared <- cor_matrix %*% cor_matrix
expected_influence_2 <- colSums(abs(cor_matrix_squared)) - diag(abs(cor_matrix_squared))

influence_df <- data.frame(
  Aspek = names(skor_aspek_label),
  EI_1_Step = round(expected_influence_1, 3),
  EI_2_Step = round(expected_influence_2, 3),
  EI_Total = round(expected_influence_1 + expected_influence_2, 3)
)

influence_df <- influence_df[order(influence_df$EI_Total, decreasing = TRUE), ]

write.csv(influence_df, "output/tables/43_Expected_Influence.csv", 
         row.names = FALSE)

# Plot expected influence
p_ei <- ggplot(influence_df, 
               aes(x = reorder(Aspek, EI_1_Step), y = EI_1_Step)) +
  geom_bar(stat = "identity", fill = "darkgreen") +
  coord_flip() +
  theme_minimal(base_size = 11) +
  labs(title = "Expected Influence - Pengaruh Total Tiap Aspek",
       subtitle = "Sum of absolute edge weights",
       x = "Aspek", y = "Expected Influence (1-Step)")

ggsave("output/plots/Network_Expected_Influence.png", p_ei, 
       width = 10, height = 8, dpi = 300)

cat("✓ Expected influence computed\n\n")

# ===== 7. FLOW ANALYSIS =====
cat("--- Network Flow Analysis ---\n")

# Analyze information flow through network
# Use betweenness as proxy for flow

flow_metrics <- data.frame(
  Aspek = names(skor_aspek_label),
  Betweenness = betweenness(g),
  Closeness = closeness(g),
  Flow_Potential = betweenness(g) * closeness(g)
)

flow_metrics <- flow_metrics[order(flow_metrics$Flow_Potential, 
                                   decreasing = TRUE), ]

write.csv(flow_metrics, "output/tables/44_Network_Flow_Metrics.csv", 
         row.names = FALSE)

# Identify bottleneck nodes (high betweenness, low closeness)
flow_metrics$Bottleneck_Score <- scale(flow_metrics$Betweenness) - 
                                 scale(flow_metrics$Closeness)

bottlenecks <- flow_metrics[order(flow_metrics$Bottleneck_Score, 
                                  decreasing = TRUE), ]

write.csv(head(bottlenecks, 10), 
          "output/tables/45_Network_Bottlenecks.csv", 
          row.names = FALSE)

cat("✓ Flow analysis completed\n\n")

# ===== 8. NETWORK RESILIENCE =====
cat("--- Network Resilience Analysis ---\n")

# Simulate node removal and measure network fragmentation
resilience_results <- data.frame(
  Node_Removed = character(),
  Components_After = integer(),
  Largest_Component_Size = integer(),
  Avg_Path_Length = numeric(),
  Fragmentation = numeric()
)

for(i in 1:ncol(cor_matrix)) {
  # Remove node i
  g_reduced <- delete_vertices(g, i)
  
  # Measure network properties
  components <- components(g_reduced)
  avg_path <- tryCatch({
    mean_distance(g_reduced, directed = FALSE)
  }, error = function(e) NA)
  
  fragmentation <- 1 - (max(components$csize) / vcount(g_reduced))
  
  resilience_results <- rbind(resilience_results, data.frame(
    Node_Removed = names(skor_aspek_label)[i],
    Components_After = components$no,
    Largest_Component_Size = max(components$csize),
    Avg_Path_Length = round(avg_path, 3),
    Fragmentation = round(fragmentation, 3)
  ))
}

# Sort by fragmentation (highest = most critical node)
resilience_results <- resilience_results[order(resilience_results$Fragmentation, 
                                               decreasing = TRUE), ]

write.csv(resilience_results, "output/tables/46_Network_Resilience.csv", 
         row.names = FALSE)

# Plot resilience
p_resilience <- ggplot(resilience_results, 
                       aes(x = reorder(Node_Removed, Fragmentation), 
                           y = Fragmentation)) +
  geom_bar(stat = "identity", fill = "firebrick") +
  coord_flip() +
  theme_minimal(base_size = 11) +
  labs(title = "Network Resilience - Dampak Menghapus Tiap Node",
       subtitle = "Fragmentation score (higher = more critical node)",
       x = "Node Removed", y = "Network Fragmentation")

ggsave("output/plots/Network_Resilience.png", p_resilience, 
       width = 10, height = 8, dpi = 300)

cat("✓ Resilience analysis completed\n\n")

# ===== 9. SMALL-WORLD PROPERTIES =====
cat("--- Small-World Analysis ---\n")

# Compare to random graph
g_random <- erdos.renyi.game(vcount(g), edge_density(g), type = "gnp")

# Compute metrics
real_clustering <- transitivity(g, type = "average")
real_path_length <- mean_distance(g, directed = FALSE)

random_clustering <- transitivity(g_random, type = "average")
random_path_length <- mean_distance(g_random, directed = FALSE)

# Small-world coefficients
sigma <- (real_clustering / random_clustering) / 
         (real_path_length / random_path_length)

omega <- (real_path_length / random_path_length) - 
         (real_clustering / random_clustering)

small_world_df <- data.frame(
  Metric = c("Clustering Coefficient (Real)", 
             "Clustering Coefficient (Random)",
             "Average Path Length (Real)",
             "Average Path Length (Random)",
             "Small-Worldness (Sigma)",
             "Small-Worldness (Omega)"),
  Value = c(round(real_clustering, 3),
            round(random_clustering, 3),
            round(real_path_length, 3),
            round(random_path_length, 3),
            round(sigma, 3),
            round(omega, 3))
)

write.csv(small_world_df, "output/tables/47_Small_World_Properties.csv", 
         row.names = FALSE)

cat("✓ Small-world analysis completed\n")
cat("Small-worldness (Sigma):", round(sigma, 3), 
    ifelse(sigma > 1, "(Small-world)", "(Not small-world)"), "\n\n")

# ===== 10. CENTRALITY CORRELATION MATRIX =====
cat("--- Centrality Correlation Analysis ---\n")

# Combine all centrality measures
all_centrality <- data.frame(
  Strength = colSums(abs(cor_matrix)) - diag(abs(cor_matrix)),
  Betweenness = betweenness(g),
  Closeness = closeness(g),
  Eigenvector = eigen_centrality(g)$vector,
  PageRank = page_rank(g)$vector,
  Expected_Influence = expected_influence_1
)

# Compute correlation between centrality measures
centrality_cor <- cor(all_centrality)

# Plot correlation heatmap
library(reshape2)
centrality_cor_melt <- melt(centrality_cor)

p_cent_cor <- ggplot(centrality_cor_melt, 
                     aes(x = Var1, y = Var2, fill = value)) +
  geom_tile() +
  geom_text(aes(label = round(value, 2)), size = 3) +
  scale_fill_gradient2(low = "blue", mid = "white", high = "red",
                       midpoint = 0, limits = c(-1, 1)) +
  theme_minimal(base_size = 11) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  labs(title = "Correlation Between Centrality Measures",
       x = "", y = "") +
  coord_fixed()

ggsave("output/plots/Network_Centrality_Correlations.png", p_cent_cor, 
       width = 10, height = 9, dpi = 300)

write.csv(centrality_cor, "output/tables/48_Centrality_Correlations.csv")

cat("✓ Centrality correlation analysis completed\n\n")

# ===== SUMMARY REPORT =====
cat("\n=== COMPARATIVE NETWORK ANALYSIS SELESAI ===\n\n")

cat("OUTPUT SUMMARY:\n")
cat("Tables created: 10 files (39-48)\n")
cat("  - Network comparison by gender\n")
cat("  - Node predictability\n")
cat("  - Edge stability\n")
cat("  - Expected influence\n")
cat("  - Network resilience\n")
cat("  - Small-world properties\n\n")

cat("Plots created: 10+ visualizations\n")
cat("  - Networks by demographic groups\n")
cat("  - Predictability charts\n")
cat("  - Expected influence\n")
cat("  - Resilience analysis\n")
cat("  - Centrality correlations\n\n")

cat("KEY FINDINGS:\n")
cat("Mean node predictability:", 
    round(mean(predictability, na.rm = TRUE), 3), "\n")
cat("Most predictable node:", 
    predictability_df$Aspek[1], 
    "(R² =", predictability_df$Predictability[1], ")\n")
cat("Least predictable node:", 
    predictability_df$Aspek[nrow(predictability_df)],
    "(R² =", predictability_df$Predictability[nrow(predictability_df)], ")\n")
cat("Small-worldness (Sigma):", round(sigma, 3), "\n")
cat("Most critical node (resilience):", 
    resilience_results$Node_Removed[1], "\n\n")

cat("All results saved in output/tables/ and output/plots/\n")
