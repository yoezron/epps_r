# ============================================================================
# SCRIPT 02: ANALISIS DESKRIPTIF DAN CLASSICAL TEST THEORY
# ============================================================================

load("output/data_processed.RData")

# ===== STATISTIK DESKRIPTIF DEMOGRAFIS =====
cat("\n=== ANALISIS DESKRIPTIF DEMOGRAFIS ===\n")

# Distribusi jenis kelamin
tbl_gender <- table(data_raw$Jenis.Kelamin)
prop_gender <- prop.table(tbl_gender) * 100

# Distribusi pendidikan
tbl_edu <- table(data_raw$Tingkat.Pendidikan)
prop_edu <- prop.table(tbl_edu) * 100

# Statistik usia
stat_usia <- data.frame(
  Mean = mean(data_raw$USIA, na.rm = TRUE),
  SD = sd(data_raw$USIA, na.rm = TRUE),
  Min = min(data_raw$USIA, na.rm = TRUE),
  Max = max(data_raw$USIA, na.rm = TRUE),
  Median = median(data_raw$USIA, na.rm = TRUE)
)

# Simpan tabel demografis
write.csv(data.frame(
  Kategori = names(tbl_gender),
  Frekuensi = as.numeric(tbl_gender),
  Persentase = round(prop_gender, 2)
), "output/tables/01_Demografis_JenisKelamin.csv", row.names = FALSE)

write.csv(data.frame(
  Kategori = names(tbl_edu),
  Frekuensi = as.numeric(tbl_edu),
  Persentase = round(prop_edu, 2)
), "output/tables/01_Demografis_Pendidikan.csv", row.names = FALSE)

write.csv(stat_usia, "output/tables/01_Statistik_Usia.csv", row.names = FALSE)

# ===== STATISTIK DESKRIPTIF SKOR ASPEK =====
cat("\n=== STATISTIK DESKRIPTIF SKOR ASPEK ===\n")

desc_aspek <- describe(skor_aspek)
desc_aspek$Aspek <- aspek_labels[rownames(desc_aspek)]
desc_aspek <- desc_aspek[, c("Aspek", "n", "mean", "sd", "min", "max", 
                              "median", "skew", "kurtosis")]

write.csv(desc_aspek, "output/tables/02_Deskriptif_Aspek.csv", row.names = TRUE)

# ===== RELIABILITAS (CRONBACH'S ALPHA & OMEGA) =====
cat("\n=== ANALISIS RELIABILITAS ===\n")

reliabilitas <- data.frame(
  Aspek = character(),
  Jumlah_Item = integer(),
  Alpha = numeric(),
  Omega = numeric(),
  stringsAsFactors = FALSE
)

for(aspek in aspek_epps) {
  item_cols <- which(trait_names == aspek)
  if(length(item_cols) > 2) {
    data_aspek <- data_items[, item_cols]
    
    # Cronbach's Alpha
    alpha_result <- alpha(data_aspek, check.keys = FALSE)
    alpha_val <- alpha_result$total$raw_alpha
    
    # McDonald's Omega
    omega_result <- tryCatch({
      omega(data_aspek, nfactors = 1, plot = FALSE)$omega.tot
    }, error = function(e) NA)
    
    reliabilitas <- rbind(reliabilitas, data.frame(
      Aspek = aspek_labels[aspek],
      Jumlah_Item = length(item_cols),
      Alpha = round(alpha_val, 3),
      Omega = round(omega_result, 3)
    ))
  }
}

write.csv(reliabilitas, "output/tables/03_Reliabilitas.csv", row.names = FALSE)

# ===== KORELASI ANTAR ASPEK =====
cat("\n=== KORELASI ANTAR ASPEK ===\n")

cor_matrix <- cor(skor_aspek, use = "pairwise.complete.obs")
colnames(cor_matrix) <- rownames(cor_matrix) <- aspek_labels[aspek_epps]

write.csv(cor_matrix, "output/tables/04_Korelasi_Aspek.csv", row.names = TRUE)

# Visualisasi korelasi
png("output/plots/01_Korelasi_Aspek.png", width = 2400, height = 2400, res = 300)
corrplot(cor_matrix, method = "color", type = "upper", 
         tl.col = "black", tl.srt = 45, tl.cex = 0.8,
         addCoef.col = "black", number.cex = 0.6,
         col = colorRampPalette(c("#D73027", "white", "#1A9850"))(200),
         title = "Matriks Korelasi Antar Aspek EPPS", 
         mar = c(0,0,2,0))
dev.off()

# ===== DISTRIBUSI SKOR =====
png("output/plots/02_Distribusi_Skor_Aspek.png", width = 4000, height = 3000, res = 300)
par(mfrow = c(3, 5), mar = c(4, 4, 2, 1))
for(i in 1:length(aspek_epps)) {
  hist(skor_aspek[, aspek_epps[i]], 
       main = aspek_labels[aspek_epps[i]],
       xlab = "Skor", ylab = "Frekuensi",
       col = "steelblue", border = "white")
  abline(v = mean(skor_aspek[, aspek_epps[i]], na.rm = TRUE), 
         col = "red", lwd = 2, lty = 2)
}
dev.off()

cat("\n=== ANALISIS DESKRIPTIF SELESAI ===\n")
cat("Output tersimpan di folder output/tables/ dan output/plots/\n")
