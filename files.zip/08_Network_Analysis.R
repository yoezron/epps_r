# ============================================================================
# SCRIPT 08: NETWORK ANALYSIS ASPEK EPPS
# ============================================================================

load("output/data_processed.RData")

cat("\n=== NETWORK ANALYSIS ANTAR ASPEK ===\n")

# Rename columns untuk visualisasi
skor_aspek_label <- skor_aspek
names(skor_aspek_label) <- aspek_labels[aspek_epps]

# ===== GAUSSIAN GRAPHICAL MODEL (GGM) =====
cat("\n--- Estimasi Network (EBICglasso) ---\n")

network <- estimateNetwork(skor_aspek_label, 
                           default = "EBICglasso",
                           corMethod = "cor",
                           missing = "pairwise")

# Plot network
png("output/plots/Network_GGM.png", width = 2800, height = 2800, res = 300)
plot(network, 
     layout = "spring",
     title = "Network Antar Aspek EPPS (Gaussian Graphical Model)",
     theme = "colorblind",
     labels = names(skor_aspek_label),
     label.cex = 1.2,
     vsize = 8,
     edge.labels = FALSE)
dev.off()

# ===== CENTRALITY MEASURES =====
cat("\n--- Analisis Centrality ---\n")

centrality_measures <- centralityTable(network)
write.csv(centrality_measures, "output/tables/25_Network_Centrality.csv", row.names = FALSE)

# Plot centrality
png("output/plots/Network_Centrality.png", width = 2400, height = 2000, res = 300)
centralityPlot(network, include = c("Strength", "Betweenness", "Closeness"),
               orderBy = "Strength",
               scale = "z-scores") +
  ggtitle("Centrality Measures - Aspek EPPS") +
  theme_minimal(base_size = 12)
dev.off()

# ===== CLUSTERING COEFFICIENT =====
cat("\n--- Clustering Coefficient ---\n")

clustering <- clustcoef_auto(network$graph)
clustering_df <- data.frame(
  Aspek = names(skor_aspek_label),
  ClusteringCoefficient = round(clustering, 3)
)
write.csv(clustering_df, "output/tables/26_Network_Clustering.csv", row.names = FALSE)

# ===== NETWORK STABILITY =====
cat("\n--- Stability Analysis (Bootstrap) ---\n")

# Bootstrap untuk stabilitas (menggunakan sample untuk efisiensi)
set.seed(2025)
sample_idx <- sample(1:nrow(skor_aspek_label), min(2000, nrow(skor_aspek_label)))
data_boot <- skor_aspek_label[sample_idx, ]

boot_result <- tryCatch({
  bootnet(data_boot, 
          nBoots = 1000,
          default = "EBICglasso",
          type = "nonparametric",
          nCores = 1)
}, error = function(e) {
  cat("Error in bootstrapping:", e$message, "\n")
  return(NULL)
})

if(!is.null(boot_result)) {
  # Plot stability
  png("output/plots/Network_Stability.png", width = 2400, height = 2000, res = 300)
  plot(boot_result, labels = FALSE, order = "sample") +
    ggtitle("Network Stability (Bootstrap)")
  dev.off()
  
  # Centrality stability
  png("output/plots/Network_CentralityStability.png", width = 2400, height = 2000, res = 300)
  plot(boot_result, statistics = c("strength", "betweenness", "closeness")) +
    ggtitle("Centrality Stability")
  dev.off()
  
  saveRDS(boot_result, "output/models/Network_Bootstrap.rds")
}

# ===== EDGE WEIGHTS =====
edge_weights <- network$graph
edge_df <- data.frame(
  From = rep(rownames(edge_weights), ncol(edge_weights)),
  To = rep(colnames(edge_weights), each = nrow(edge_weights)),
  Weight = as.vector(edge_weights)
)
edge_df <- edge_df[edge_df$Weight != 0, ]
edge_df <- edge_df[order(abs(edge_df$Weight), decreasing = TRUE), ]

write.csv(edge_df, "output/tables/27_Network_EdgeWeights.csv", row.names = FALSE)

# ===== COMMUNITY DETECTION =====
cat("\n--- Community Detection ---\n")

library(igraph)
g <- graph_from_adjacency_matrix(abs(edge_weights), 
                                 mode = "undirected", 
                                 weighted = TRUE, 
                                 diag = FALSE)
communities <- cluster_walktrap(g)

community_df <- data.frame(
  Aspek = names(skor_aspek_label),
  Community = communities$membership
)
write.csv(community_df, "output/tables/28_Network_Communities.csv", row.names = FALSE)

# Plot dengan community colors
png("output/plots/Network_Communities.png", width = 2800, height = 2800, res = 300)
plot(network,
     layout = "spring",
     groups = communities$membership,
     title = "Network dengan Community Detection",
     labels = names(skor_aspek_label),
     label.cex = 1.2,
     vsize = 8)
dev.off()

cat("\n=== NETWORK ANALYSIS SELESAI ===\n")
cat("Network stability analysis completed\n")
cat("Centrality measures dan communities tersimpan\n")
