# ============================================================================
# SCRIPT 06: THURSTONIAN IRT (TIRT) - UNTUK FORCED-CHOICE DATA
# ============================================================================

load("output/data_processed.RData")

cat("\n=== ANALISIS THURSTONIAN IRT ===\n")
cat("Model khusus untuk data forced-choice EPPS\n\n")

# Sampling untuk efisiensi komputasi
set.seed(2025)
sample_size <- min(1500, nrow(data_items))
sample_idx <- sample(1:nrow(data_items), sample_size)
data_sample <- data_items[sample_idx, ]

cat("Sample size untuk TIRT:", sample_size, "\n")

# ===== PERSIAPAN DATA UNTUK TIRT =====
# Identifikasi pairs dari forced-choice
item_info <- data.frame(
  item = names(data_items),
  trait = trait_names,
  stringsAsFactors = FALSE
)

# Filter item yang valid
item_info <- item_info[!is.na(item_info$trait), ]

# Buat blocks (pairs) dari forced-choice items
# Asumsi: item dengan nomor yang sama adalah satu pair
extract_item_number <- function(item_name) {
  parts <- strsplit(item_name, " ")[[1]]
  num_part <- gsub("[^0-9]", "", parts[1])
  return(num_part)
}

item_info$block <- sapply(item_info$item, extract_item_number)

# Hitung jumlah blocks
blocks <- unique(item_info$block)
cat("Jumlah blocks (pairs):", length(blocks), "\n")

# ===== FIT THURSTONIAN IRT MODEL =====
cat("\n--- Fitting Thurstonian IRT Model ---\n")

# Buat spesifikasi model untuk thurstonianIRT
# Format: trait BY item1, item2, item3, ...

traits_list <- lapply(aspek_epps, function(trait) {
  items <- item_info$item[item_info$trait == trait]
  return(items)
})
names(traits_list) <- aspek_epps

# Fit model TIRT
model_tirt <- tryCatch({
  # Konversi data menjadi format yang sesuai
  data_long <- data_sample
  
  # Model specification
  tirt_spec <- paste0(
    aspek_labels[aspek_epps], " =~ ",
    sapply(aspek_epps, function(a) {
      items <- item_info$item[item_info$trait == a]
      paste(items, collapse = " + ")
    })
  )
  tirt_spec <- paste(tirt_spec, collapse = "\n")
  
  # Fit menggunakan lavaan dengan estimator yang sesuai
  fit_tirt <- cfa(tirt_spec, data = data_long, 
                  ordered = TRUE, 
                  estimator = "WLSMV",
                  std.lv = TRUE)
  
  fit_tirt
}, error = function(e) {
  cat("Error fitting TIRT:", e$message, "\n")
  return(NULL)
})

if(!is.null(model_tirt)) {
  # Extract fit measures
  fit_measures <- fitMeasures(model_tirt, c("chisq", "df", "pvalue", 
                                             "cfi", "tli", "rmsea", 
                                             "rmsea.ci.lower", "rmsea.ci.upper",
                                             "srmr"))
  
  fit_df <- data.frame(
    Index = names(fit_measures),
    Value = round(as.numeric(fit_measures), 4)
  )
  
  write.csv(fit_df, "output/tables/14_TIRT_FitIndices.csv", row.names = FALSE)
  
  # Parameter estimates
  params_tirt <- parameterEstimates(model_tirt, standardized = TRUE)
  params_tirt <- params_tirt[params_tirt$op == "=~", ]
  
  write.csv(params_tirt, "output/tables/15_TIRT_Parameters.csv", row.names = FALSE)
  
  # Factor correlations
  cor_tirt <- lavInspect(model_tirt, "cor.lv")
  colnames(cor_tirt) <- rownames(cor_tirt) <- aspek_labels[aspek_epps]
  
  write.csv(cor_tirt, "output/tables/16_TIRT_TraitCorrelations.csv", row.names = TRUE)
  
  # Plot trait correlations
  png("output/plots/TIRT_TraitCorrelations.png", width = 2400, height = 2400, res = 300)
  corrplot(cor_tirt, method = "color", type = "upper",
           tl.col = "black", tl.srt = 45, tl.cex = 0.8,
           addCoef.col = "black", number.cex = 0.6,
           col = colorRampPalette(c("#D73027", "white", "#1A9850"))(200),
           title = "Korelasi Antar Trait (Thurstonian IRT)",
           mar = c(0,0,2,0))
  dev.off()
  
  # Factor scores (trait estimates)
  fscores_tirt <- lavPredict(model_tirt)
  colnames(fscores_tirt) <- aspek_labels[aspek_epps]
  
  write.csv(fscores_tirt, "output/tables/17_TIRT_TraitScores_Sample.csv", row.names = FALSE)
  
  # Reliability (Omega)
  reliability_tirt <- reliability(model_tirt)
  rel_df <- data.frame(
    Trait = aspek_labels[aspek_epps],
    Omega = round(as.numeric(reliability_tirt), 3)
  )
  
  write.csv(rel_df, "output/tables/18_TIRT_Reliability.csv", row.names = FALSE)
  
  # Simpan model
  saveRDS(model_tirt, "output/models/TIRT_model.rds")
  
  # Summary
  sink("output/tables/19_TIRT_Summary.txt")
  summary(model_tirt, fit.measures = TRUE, standardized = TRUE)
  sink()
  
  cat("\n=== THURSTONIAN IRT SELESAI ===\n")
  cat("Model fit indices: CFI =", round(fit_measures["cfi"], 3), 
      ", TLI =", round(fit_measures["tli"], 3),
      ", RMSEA =", round(fit_measures["rmsea"], 3), "\n")
}
