# ============================================================================
# SCRIPT 07: GRADED RESPONSE MODEL (GRM)
# Untuk analisis polytomous pada skor agregat per aspek
# ============================================================================

load("output/data_processed.RData")

cat("\n=== ANALISIS GRADED RESPONSE MODEL ===\n")

# Sampling
set.seed(2025)
sample_idx <- sample(1:nrow(skor_aspek), min(2000, nrow(skor_aspek)))
data_grm <- skor_aspek[sample_idx, ]

cat("Sample size:", nrow(data_grm), "\n")
cat("Menganalisis skor agregat sebagai data polytomous\n\n")

# ===== FIT GRM MODEL =====
# Model 1: Unidimensional (semua aspek mengukur trait umum)
cat("--- Fitting GRM Unidimensional ---\n")

model_grm_uni <- tryCatch({
  mirt(data_grm, model = 1, itemtype = "graded", 
       verbose = FALSE, technical = list(NCYCLES = 1000))
}, error = function(e) {
  cat("Error:", e$message, "\n")
  return(NULL)
})

if(!is.null(model_grm_uni)) {
  # Fit indices
  fit_uni <- M2(model_grm_uni)
  
  fit_stats_uni <- data.frame(
    Model = "GRM_Unidimensional",
    M2 = round(fit_uni$M2, 2),
    df = fit_uni$df,
    p_value = round(fit_uni$p, 4),
    RMSEA = round(fit_uni$RMSEA, 4),
    CFI = round(fit_uni$CFI, 4),
    TLI = round(fit_uni$TLI, 4),
    SRMSR = round(fit_uni$SRMSR, 4)
  )
  
  write.csv(fit_stats_uni, "output/tables/20_GRM_Uni_FitIndices.csv", row.names = FALSE)
  
  # Parameter
  params_uni <- coef(model_grm_uni, simplify = TRUE)
  write.csv(params_uni$items, "output/tables/21_GRM_Uni_Parameters.csv", row.names = TRUE)
  
  # Item information
  png("output/plots/GRM_Uni_ItemInfo.png", width = 3000, height = 2400, res = 300)
  itemplot(model_grm_uni, 1, type = "info", 
           main = "Item Information - GRM Unidimensional")
  dev.off()
  
  # Test information
  png("output/plots/GRM_Uni_TestInfo.png", width = 2400, height = 1800, res = 300)
  plot(model_grm_uni, type = "info", 
       main = "Total Information Function - GRM Unidimensional",
       xlab = "Trait Level (Theta)",
       ylab = "Information")
  dev.off()
  
  saveRDS(model_grm_uni, "output/models/GRM_Unidimensional.rds")
}

# Model 2: Bifactor (general + specific factors)
cat("\n--- Fitting GRM Bifactor Model ---\n")

# Spesifikasi bifactor: 1 faktor umum + 15 faktor spesifik
bifactor_spec <- '
G = 1-15
S1 = 1
S2 = 2
S3 = 3
S4 = 4
S5 = 5
S6 = 6
S7 = 7
S8 = 8
S9 = 9
S10 = 10
S11 = 11
S12 = 12
S13 = 13
S14 = 14
S15 = 15
COV = G*S1, G*S2, G*S3, G*S4, G*S5, G*S6, G*S7, G*S8, G*S9, G*S10, 
      G*S11, G*S12, G*S13, G*S14, G*S15
'

model_grm_bi <- tryCatch({
  mirt(data_grm, model = bifactor_spec, itemtype = "graded",
       verbose = FALSE, technical = list(NCYCLES = 1000))
}, error = function(e) {
  cat("Error:", e$message, "\n")
  return(NULL)
})

if(!is.null(model_grm_bi)) {
  fit_bi <- M2(model_grm_bi)
  
  fit_stats_bi <- data.frame(
    Model = "GRM_Bifactor",
    M2 = round(fit_bi$M2, 2),
    df = fit_bi$df,
    p_value = round(fit_bi$p, 4),
    RMSEA = round(fit_bi$RMSEA, 4),
    CFI = round(fit_bi$CFI, 4),
    TLI = round(fit_bi$TLI, 4),
    SRMSR = round(fit_bi$SRMSR, 4)
  )
  
  write.csv(fit_stats_bi, "output/tables/22_GRM_Bifactor_FitIndices.csv", row.names = FALSE)
  
  params_bi <- coef(model_grm_bi, simplify = TRUE)
  write.csv(params_bi$items, "output/tables/23_GRM_Bifactor_Parameters.csv", row.names = TRUE)
  
  saveRDS(model_grm_bi, "output/models/GRM_Bifactor.rds")
}

# Perbandingan model
if(!is.null(model_grm_uni) && !is.null(model_grm_bi)) {
  comparison <- anova(model_grm_uni, model_grm_bi)
  write.csv(comparison, "output/tables/24_GRM_ModelComparison.csv", row.names = TRUE)
}

cat("\n=== GRADED RESPONSE MODEL SELESAI ===\n")
